import 'package:flutter/material.dart';
import '../../widgets/customer_navigation_drawer.dart';


class CustomerApplyLoanScreen extends StatefulWidget {
  @override
  _CustomerApplyLoanScreenState createState() => _CustomerApplyLoanScreenState();
}

class _CustomerApplyLoanScreenState extends State<CustomerApplyLoanScreen> {
  final _formKey = GlobalKey<FormState>();

  // Define controllers for form fields
  TextEditingController _loanAmountController = TextEditingController();
  TextEditingController _loanTermController = TextEditingController();
  TextEditingController _loanPurposeController = TextEditingController();

  @override
  void dispose() {
    // Dispose controllers when the widget is disposed
    _loanAmountController.dispose();
    _loanTermController.dispose();
    _loanPurposeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Apply for Loan',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.purpleAccent,
      ),
      drawer: CustomerNavigationDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Loan Amount Field
              TextFormField(
                controller: _loanAmountController,
                decoration: InputDecoration(
                  labelText: 'Loan Amount',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter loan amount';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Loan Term Field
              TextFormField(
                controller: _loanTermController,
                decoration: InputDecoration(
                  labelText: 'Loan Term (in months)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter loan term';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Loan Purpose Field
              TextFormField(
                controller: _loanPurposeController,
                decoration: InputDecoration(
                  labelText: 'Purpose of Loan',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the purpose of the loan';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Submit Button
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Perform form submission (save data to backend)
                      _submitLoanApplication();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purpleAccent, // Updated from `primary`
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  ),
                  child: Text(
                    'Submit Application',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Function to handle the form submission
  void _submitLoanApplication() {
    final loanAmount = _loanAmountController.text;
    final loanTerm = _loanTermController.text;
    final loanPurpose = _loanPurposeController.text;

    // Show confirmation dialog or send data to the server
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Loan Application Submitted'),
        content: Text(
            'Loan Amount: $loanAmount\nLoan Term: $loanTerm months\nPurpose: $loanPurpose'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Go back to previous screen
            },
            child: Text('OK'),
          ),
        ],
      ),
    );

    // Clear form after submission
    _loanAmountController.clear();
    _loanTermController.clear();
    _loanPurposeController.clear();
  }
}
